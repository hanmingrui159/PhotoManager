import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.HashMap;

/**
 * <h1> PictureManager </h1>
 * PictureManager object stores a HashMap of Pictures with their unique Integer ID.
 * Its storage of Pictures can be saved to local files and read when the program reopens later.
 */
class PictureManager {

    static int picID = 0;
    static HashMap<Integer, Picture> PicStorage = new HashMap<>();

    /**
     * Saves the HashMap of Pictures to a local file with the file path specified in the parameter.
     * @param path file path that the HashMap of Pictures to be saved at.
     * @throws IOException the Exception is thrown when  failure of saving occurs
     * when the directory containing the file path doesn't exist
     */
    static void saveToFile(String path) throws IOException {
        OutputStream file = new FileOutputStream(path);
        OutputStream buffer = new BufferedOutputStream(file);
        ObjectOutput output = new ObjectOutputStream(buffer);

        output.writeObject(PictureManager.PicStorage);
        output.close();
    }

    /**
     * Reading the saved file of Pictures back to the PictureManager's HashMap PictureManager.PicStorage
     * @param path path of the saved file to be read from
     * @throws ClassNotFoundException Exception is thrown when the designated file does not exist or
     * the directory does not exist.
     */
    static void readFromFile(String path) throws ClassNotFoundException {
        try {
            InputStream file = new FileInputStream(path);
            InputStream buffer = new BufferedInputStream(file);
            ObjectInput input = new ObjectInputStream(buffer);

            PictureManager.PicStorage = (HashMap<Integer, Picture>) input.readObject();
            input.close();
        } catch (IOException ex) { }
    }

}
