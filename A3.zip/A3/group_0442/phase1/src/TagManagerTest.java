import org.junit.jupiter.api.Test;
import java.io.File;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TagManagerTest {

    @Test
    public void testCreateTag(){
        Tag a = new Tag("test");
        assertEquals(a, TagManager.createTag("test"));
        assertEquals(a, TagManager.findThisTag("test"));

    }

    @Test
    public void testDeleteTag(){
        Tag a = new Tag("test");
        TagManager.createTag("test");
        assertEquals(a, TagManager.findThisTag("test"));
        TagManager.deleteTag(a);
        assertEquals(null, TagManager.findThisTag("test"));
    }

    @Test
    public void testSaveToFile(){
        Tag a = new Tag("test");
        TagManager.createTag("test");

        try {
            TagManager.saveToFile("tagSaveTest.ser");
        } catch (IOException e){ }

        try {
            TagManager.readFromFile("tagSaveTest.ser");
        } catch (ClassNotFoundException e1) {
        }

        assertEquals(a, TagManager.findThisTag("test"));

        File f = new File("tagSaveTest.ser");
        f.delete();
    }



    @Test
    public void testReadFromFile(){
        Tag a = new Tag("test");
        TagManager.createTag("test");

        try {
            TagManager.saveToFile("tagSaveTest.ser");
        } catch (IOException e){ }

        try {
            TagManager.readFromFile("tagSaveTest.ser");
        } catch (ClassNotFoundException e1) {
        }

        assertEquals(a, TagManager.findThisTag("test"));
        assertEquals(null, TagManager.findThisTag("s"));

        File f = new File("tagSaveTest.ser");
        f.delete();
    }

    @Test
    public void testAddToLog(){


    }

    @Test
    public void testFindThisTag(){
        Tag a = new Tag("test");
        TagManager.createTag("test");
        assertEquals(a, TagManager.findThisTag("test"));
        assertEquals(null, TagManager.findThisTag("dfd"));

    }

}
