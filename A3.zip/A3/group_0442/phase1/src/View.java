import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class View extends Application {

  private int currentID = -1;
  private Image currentImage;
  final static Logger LOGGER = Logger.getLogger("MyLog");

  private final String tagSaveLocation = "tagsave.ser";
  private final String pictureSaveLocation = "picturesave.ser";

  public static void main(String[] args) {
    launch(args);
  }

  @Override
  public void start(Stage stage) {
    try {
      TagManager.readFromFile(tagSaveLocation);
    } catch (ClassNotFoundException e) { }
    try {
      PictureManager.readFromFile(pictureSaveLocation);
    } catch (ClassNotFoundException e) { }
    GridPane root = new GridPane();
    root.setHgap(8);
    root.setVgap(8);
    root.setPadding(new Insets(10, 10, 10, 10));

    ColumnConstraints cons1 = new ColumnConstraints();
    cons1.setHgrow(Priority.NEVER);
    root.getColumnConstraints().add(cons1);
    ColumnConstraints cons2 = new ColumnConstraints();
    cons2.setHgrow(Priority.ALWAYS);

    root.getColumnConstraints().addAll(cons1, cons2);

    RowConstraints rcons1 = new RowConstraints();
    rcons1.setVgrow(Priority.NEVER);
    RowConstraints rcons2 = new RowConstraints();
    rcons2.setVgrow(Priority.ALWAYS);

    root.getRowConstraints().addAll(rcons1, rcons2);

    ListView<Tag> listOfAllTags = new ListView<>(); //all existing tags
    listOfAllTags.setEditable(false);
    listOfAllTags.setItems(TagManager.listOfTags);
    listOfAllTags.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

    ListView<Tag> listOfPictureTags = new ListView<>(); //tags belonging to the current image
    ObservableList<Tag> pictureTags = FXCollections.observableArrayList();
    listOfPictureTags.setEditable(false);
    listOfPictureTags.setItems(pictureTags);
    listOfPictureTags.setOrientation(Orientation.HORIZONTAL);
    listOfPictureTags.setMaxHeight(50);
    listOfPictureTags.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

    Text absolutePath = new Text("Open an image to begin");

    Button openPicBtn = new Button("Open a new Image");
    Button openInOSBtn = new Button("View Directory");
    Button createNewTagBtn = new Button("Create New Tag");
    Button deleteTagBtn = new Button("Delete Tag");
    Button addSelectedTagBtn = new Button("Add Tag");
    Button removeTagButton = new Button("Remove Selected Tag");
    Button renameBtn = new Button("Rename!");
    Button revertBtn = new Button("Revert Changes");
    Button openLogBtn = new Button("Open Log");
    Button moveBtn = new Button("Move Image");

    ImageView iv = new ImageView(); //displays the image
    iv.setFitWidth(300);
    iv.setPreserveRatio(true);

    FileChooser fileChooser = new FileChooser();
    FileChooser.ExtensionFilter imageFilter
        = new FileChooser.ExtensionFilter("Image Files", "*.jpg", "*.png");
    fileChooser.getExtensionFilters().add(imageFilter);

    VBox box1 = new VBox();
    box1.getChildren().addAll(iv, listOfPictureTags);
    box1.setSpacing(10);
    root.add(box1, 0, 0);

    HBox btnBox1 = new HBox(5);
    btnBox1.getChildren().addAll(addSelectedTagBtn, removeTagButton, openInOSBtn);
    GridPane.setHalignment(btnBox1, HPos.RIGHT);
    root.add(btnBox1, 0, 1);

    HBox btnBox2 = new HBox(5);
    btnBox2.getChildren().addAll(renameBtn, revertBtn, openPicBtn);
    GridPane.setHalignment(btnBox2, HPos.RIGHT);
    root.add(btnBox2, 0, 2);

    HBox btnBox3 = new HBox(5);
    btnBox3.getChildren().addAll(createNewTagBtn, deleteTagBtn, openLogBtn);
    GridPane.setHalignment(btnBox3, HPos.RIGHT);
    root.add(btnBox3, 0, 3);

    HBox btnBox4 = new HBox(5);
    btnBox4.getChildren().addAll(moveBtn, absolutePath);
    GridPane.setHalignment(btnBox4, HPos.RIGHT);
    root.add(btnBox4, 0, 4);

    openPicBtn.setOnAction((event) -> {
      File file = fileChooser.showOpenDialog(stage);
      if (file != null) {
        if (currentID != -1) {
          PictureManager.PicStorage.get(currentID).rename();
        }
        currentImage = new Image("file:" + file.getAbsolutePath(), 300, 300, true, true);
        absolutePath.setText(file.getAbsolutePath());
        for (Integer k : PictureManager.PicStorage.keySet()) {
          if (PictureManager.PicStorage.get(k).getNameWithTags().equals(file.getAbsolutePath())) {
            iv.setImage(currentImage);
            currentID = k;
            listOfPictureTags.setItems(FXCollections
                .observableArrayList(PictureManager.PicStorage.get(k).arrayTagsUsed));
            return;
          }
        }
        currentID = PictureManager.picID;
        PictureManager.PicStorage
            .put(PictureManager.picID, new Picture(file.getAbsolutePath(), file.getName()));
        listOfPictureTags.setItems(FXCollections
            .observableArrayList(PictureManager.PicStorage.get(currentID).arrayTagsUsed));
        iv.setImage(currentImage);
      }
    });

    openInOSBtn.setOnAction((event) -> {
      if (currentID != -1) {
        PictureManager.PicStorage.get(currentID).openInOS();
      }
    });

    createNewTagBtn.setOnAction((event) -> {
      Stage newTagStage = new Stage();
      TextField textUser = new TextField();
      textUser.setPromptText("Enter name of new Tag.");
      Button okBtn = new Button("Create");
      okBtn.setOnAction((eventOK) -> {
        String txt = textUser.getText().trim();
        if (TagManager.findThisTag(txt) == null) {
          TagManager.createTag(txt);
        }
        newTagStage.close();
      });

      Button cancelBtn = new Button("Cancel");
      cancelBtn.setOnAction((eventCancel) -> newTagStage.close());

      GridPane newTagPane = new GridPane();
      newTagPane.setHgap(8);
      newTagPane.setVgap(8);
      newTagPane.setPadding(new Insets(10, 10, 10, 10));
      newTagPane.add(textUser, 0, 0, 2, 1);
      newTagPane.add(okBtn, 0, 1);
      newTagPane.add(cancelBtn, 1, 1);
      Scene newTagScene = new Scene(newTagPane);
      newTagStage.setScene(newTagScene);
      newTagStage.show();
    });

    deleteTagBtn.setOnAction((event) -> {
      ObservableList<Tag> begone  = listOfAllTags.getSelectionModel().getSelectedItems();
      if (begone != null) {
        for (int k : PictureManager.PicStorage.keySet()) {
          for (Tag deleteMe : begone) {
            PictureManager.PicStorage.get(k).removeTag(deleteMe);
          }
          PictureManager.PicStorage.get(k).rename();
          if (k == currentID) {
            absolutePath.setText(PictureManager.PicStorage.get(currentID).getNameWithTags());
            listOfPictureTags.setItems(
                FXCollections.observableArrayList(PictureManager.PicStorage.get(k).arrayTagsUsed));
          }
        }
        for (Tag t : begone) {
          TagManager.deleteTag(t);
        }
      }
    });

    addSelectedTagBtn.setOnAction((event) -> {
      ObservableList<Tag> contenders  = listOfAllTags.getSelectionModel().getSelectedItems();
      if (currentID != -1 && contenders != null) {
        for (Tag t : contenders) {
          PictureManager.PicStorage.get(currentID).addTag(t);
        }
        listOfPictureTags.setItems(FXCollections
            .observableArrayList(PictureManager.PicStorage.get(currentID).arrayTagsUsed));
        PictureManager.PicStorage.get(currentID).rename();
        absolutePath.setText(PictureManager.PicStorage.get(currentID).getNameWithTags());
      }
    });

    removeTagButton.setOnAction((event) -> {
      ObservableList<Tag> removables  = listOfPictureTags.getSelectionModel().getSelectedItems();
      if (currentID != -1 && removables != null) {
        for (Tag t : removables) {
          PictureManager.PicStorage.get(currentID).removeTag(t);
        }
        listOfPictureTags.setItems(FXCollections
            .observableArrayList(PictureManager.PicStorage.get(currentID).arrayTagsUsed));
        PictureManager.PicStorage.get(currentID).rename();
        absolutePath.setText(PictureManager.PicStorage.get(currentID).getNameWithTags());
      }
    });

    renameBtn.setOnAction((event) -> {
      if (currentID != -1) {
        PictureManager.PicStorage.get(currentID).rename();
        absolutePath.setText(PictureManager.PicStorage.get(currentID).getNameWithTags());
      }
    });

    revertBtn.setOnAction((event) -> {
      if (currentID != -1) {
        Stage revertStage = new Stage();
        ListView<String> listOfRevertTags = new ListView<>(); //all existing tags
        listOfRevertTags.setEditable(false);
        listOfRevertTags.setItems(FXCollections
            .observableArrayList(PictureManager.PicStorage.get(currentID).arrayPastNames));
        listOfRevertTags.setMaxHeight(500);
        Button selectBtn = new Button("Revert to this name");
        selectBtn.setOnAction((eventSelect) -> {
          String revertToMe = listOfRevertTags.getSelectionModel().getSelectedItem();
          if (revertToMe != null) {
            PictureManager.PicStorage.get(currentID).revertToPrevious(revertToMe);
            listOfPictureTags.setItems(FXCollections
                .observableArrayList(PictureManager.PicStorage.get(currentID).arrayTagsUsed));
            absolutePath.setText(PictureManager.PicStorage.get(currentID).getNameWithTags());
          }
          revertStage.close();
        });
        Button cancelBtn = new Button("Cancel");
        cancelBtn.setOnAction((eventCancel) -> revertStage.close());

        GridPane revertPane = new GridPane();
        revertPane.setHgap(8);
        revertPane.setVgap(8);
        revertPane.setPadding(new Insets(10, 10, 10, 10));
        revertPane.add(listOfRevertTags, 1, 0, 2, 1);
        revertPane.add(selectBtn, 0, 0);
        revertPane.add(cancelBtn, 0, 1);
        Scene newTagScene = new Scene(revertPane);
        revertStage.setScene(newTagScene);
        revertStage.show();
      }
    });

    openLogBtn.setOnAction((event) -> {
      if( Desktop.isDesktopSupported() )
      {
        new Thread(() -> {
          try {
            Desktop.getDesktop().open(new File("MyLog.log") );
          } catch (IOException e1) {
            e1.printStackTrace();
          }
        }).start();
      }
    });

    moveBtn.setOnAction((event) -> {
      if (currentID != -1) {
        DirectoryChooser directoryChooser = new DirectoryChooser();
        File selectedDirectory = directoryChooser.showDialog(stage);
        if (selectedDirectory != null) {
          PictureManager.PicStorage.get(currentID).moveTo(selectedDirectory.getAbsolutePath());
          absolutePath.setText(PictureManager.PicStorage.get(currentID).getNameWithTags());
        }
      }
    });

    root.add(listOfAllTags, 2, 0, 2, 4);
    Scene scene = new Scene(root, 550, 475);
    stage.setTitle("CSC207 FINAL PROJECT");
    stage.setScene(scene);
    stage.sizeToScene();
    stage.show();

    try { //start up the log
      FileHandler fh = new FileHandler("MyLog.log", true);
      LOGGER.addHandler(fh);
      SimpleFormatter formatter = new SimpleFormatter();
      fh.setFormatter(formatter);
      LOGGER.info("=== STARTED PROGRAM ===");
    } catch (IOException e) { }

    stage.setOnCloseRequest((WindowEvent event) -> {
      // save everything
      try {
        TagManager.saveToFile(tagSaveLocation);
      } catch (IOException e) { }
      try {
        PictureManager.saveToFile(pictureSaveLocation);
      } catch (IOException e) { }
    });
  }
}
