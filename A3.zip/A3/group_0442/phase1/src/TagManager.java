import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
/**
 * <h1> TagManager </h1>
 * The TagManager program implements an application that manages Tag objects.
 * <p>
 * The TagManager can add, delete, find Tags and save Tags to, read Tags from files.
 */
class TagManager implements Serializable {
    /**
     * A list of tags for displaying Tags on the screen.
     */
    static transient ObservableList<Tag> listOfTags = FXCollections.observableArrayList();
    /**
     * An ArrayList of Tags.
     */
    private static ArrayList<Tag> arrayListOfTags = new ArrayList<>();

    /**
     * Creates a Tag object with given name.
     * @param name the name of the created Tag.
     * @return the created Tag.
     */
    static Tag createTag(String name) {
        Tag a = new Tag(name);
        listOfTags.add(a);
        arrayListOfTags.add(a);
        return a;
    }

    /**
     * Deletes an existing Tag.
     * @param t a Tag to be deleted.
     */
    static void deleteTag(Tag t) {
        if (listOfTags.contains(t)) {
            listOfTags.remove(t);
            arrayListOfTags.remove(t);
        }
    }

    /**
     * Save existing Tags to a file
     * @param path the path where the file is
     * @throws IOException if the path doesn't exist
     */
    static void saveToFile(String path) throws IOException {
        OutputStream file = new FileOutputStream(path);
        OutputStream buffer = new BufferedOutputStream(file);
        ObjectOutput output = new ObjectOutputStream(buffer);

        output.writeObject(arrayListOfTags);
        output.close();
    }

    /**
     * Read Tags from a given file
     * @param path the path of the file.
     * @throws ClassNotFoundException if there's no required file under the given path.
     */
    static void readFromFile(String path) throws ClassNotFoundException {
        try {
            InputStream file = new FileInputStream(path);
            InputStream buffer = new BufferedInputStream(file);
            ObjectInput input = new ObjectInputStream(buffer);

            arrayListOfTags = (ArrayList<Tag>) input.readObject();
            listOfTags = FXCollections.observableArrayList(arrayListOfTags);
            input.close();

        } catch (IOException ex) { }
    }

    /**
     * Add rename information to log.
     * @param old the old name of a picture.
     * @param cur the new name of a picture.
     */
    static void addToLog(String old, String cur) {
        View.LOGGER.info(String.format("RENAMED:  <%s>  TO  <%s>", old, cur) +
                System.lineSeparator());
    }

    /**
     * Find the Tag with given name.
     * @param name the name of a potential Tag.
     * @return the Tag with given name if it exists; null otherwise.
     */
    static Tag findThisTag(String name) {
        for (Tag t : listOfTags) {
            if (t.getName().equals(name)) {
                return t;
            }
        }
        return null;
    }


}