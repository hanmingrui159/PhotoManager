import java.io.Serializable;

/**
 * <h1> Tag </h1>
 * The Tag program implements an application that creates a Tag with given string.
 * <p>
 * A Tag can be compared and has a string representation.
 */
public class Tag implements Serializable {
    /**
     * The content of a Tag
     */
    private String name;

    /**
     * Constructs a new Tag with given String name.
     *
     * @param name the content of a Tag
     */
    Tag(String name) {
        this.name = name;
    }

    /**
     * Gets the name of a Tag.
     * @return the name of a Tag.
     */
    String getName() {
        return this.name;
    }

    /**
     * Gets the string representation of a Tag.
     * @return a string consisting of @ and the name of a Tag.
     */
    public String toString() {
        return "@" + this.name;
    }

    /**
     * Indicates whether some object is "equal to" this Tag.
     * @param o some other object
     * @return true if this object is the same as the obj argument false otherwise.
     */
    @Override
    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof Tag)) {
            return false;
        }
        Tag t = (Tag) o;
        return this.name.equals(t.getName());
    }
}