import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.regex.Pattern;

/**
 * <h1> Picture </h1>
 * The Picture class records the information about a picture with ogFileAddress, the picture's
 * current name and ID, etc.
 */
public class Picture implements Serializable {

  private String ogFileAddress;
  private String name;
  private String nameWithTags;
  private String extension;
  private int ID;
  ArrayList<Tag> arrayTagsUsed;
  ArrayList<String> arrayPastNames;

  /**
   * Constructs a Picture with the given file address.
   */
  Picture(String address, String name) {

    this.ogFileAddress = address
        .substring(0, address.lastIndexOf(File.separator) + 1); //file location not including file name
    this.nameWithTags = address; //full thing
    this.extension = "." + address.substring(address.lastIndexOf('.') + 1); //eg. '.jpg', '.png'
    this.name = name.substring(0, name.indexOf(this.extension)); //only file name
    this.arrayTagsUsed = new ArrayList<>();
    this.arrayPastNames = new ArrayList<>();
    this.ID = PictureManager.picID++; //increases picID to keep it unique
    PictureManager.PicStorage.put(this.ID, this); //stores object in hashmap
  }

  /**
   * getter method for this.nameWithTags.
   *
   * @return getNameWithTags() returns the current name of the Picture.
   */
  String getNameWithTags() {
    return this.nameWithTags;
  }

  /**
   * getter method for the this.ID of the Picture.
   *
   * @return an Integer ID of the Picture.
   */
  private int getID() {
    return this.ID;
  }

  /**
   * getter method for this.ogFileAddress
   * @return a String of the original file address
   */
  private String getOgFileAddress() {
    return this.ogFileAddress;
  }

  /**
   * setter method for this.ogFileAddress.
   * @param address String to set this.ogFileAddress
   */

  private void setOgFileAddress(String address) {
    this.ogFileAddress = address;
  }

  /**
   * Adds Tag t to the Picture's (ArrayList)arrayTagsUsed.
   * @param t Tag to be added.
   */
  void addTag(Tag t) {
    if (!this.arrayTagsUsed.contains(t)) {
      this.arrayTagsUsed.add(t);
    }
  }

  /**
   * Removes Tag t from the Picture Object's arrayTagsUsed.
   * @param t Tag to be removed from this Picture
   */
  void removeTag(Tag t) {
    if (t != null) {
      if (this.arrayTagsUsed.contains(t)) {
        this.arrayTagsUsed.remove(t);
      }
    }
  }

  /**
   * Adds the name to its arrayPastNames.
   * @param name name to be added.
   */
  private void addPastName(String name) {
    if (!this.arrayPastNames.contains(name)) {
      this.arrayPastNames.add(name);
    }
  }

  /**
   * Renames the name of the Picture object according to its original name, Tag's in arrayTagsUsed and extension.
   * If the renaming is a success, add the previous name to arrayPastNames, log the success. If a failure, log
   * the failure
   */
  void rename() {
    StringBuilder tags = new StringBuilder();
    for (Tag t : this.arrayTagsUsed) {
      tags.append(" ");
      tags.append(t.toString());
    }
    String pastName = this.nameWithTags;
    this.nameWithTags = this.ogFileAddress + this.name + tags + this.extension;
    this.changeFileLocation(pastName, this.nameWithTags);
  }

  /**
   * Returns a String representation of the Picture
   * @return String representation of the Picture
   */
  public String toString() {
    return "a Picture: " + this.nameWithTags;
  }

  /**
   * opens the directory that contains the current Picture in Using the file explorer provided by the Operating System.
   */
  void openInOS() {
    if( Desktop.isDesktopSupported() )
    {
      new Thread(() -> {
        try {
          Desktop.getDesktop().open(new File(this.ogFileAddress) );
        } catch (IOException e1) {
          e1.printStackTrace();
        }
      }).start();
    }
  }

  /**
   * Change the current name nameWithTags and arrayTagsUsed of the Picture back to the name 'previous'.
   *
   * @param previous a past name that the Picture will change back to.
   */
  void revertToPrevious(String previous) {
    String folders = previous.substring(0, previous.lastIndexOf(File.separator) + 1);
    String rest = previous.substring(previous.lastIndexOf(File.separator) + 1, previous.length());
    String[] tagsAfterName = rest.split(" @");
    if (!(this.ogFileAddress.equals(folders))) { //make sure path is the same
      this.setOgFileAddress(folders);
    }
    // reconstruct arrayTagsUsed with the given past name.
    this.arrayTagsUsed.clear();
    if (!(tagsAfterName[0].replace(" @", "").equals(this.extension))) { // check if .jpg is the only thing after this.name (tagsAfterName is
      // the list split of string after this.name in the past name)
      updateTagsFromPastName(tagsAfterName);
    }
    this.rename();
  }

  /**
   * helper for Picture.revertToPrevious(),
   * create association between tags in the Past Name and this Picture,
   * by adding Tags to Picture.arrayTagsUsed and add the Picture to according Tags in TagManager.
   * if a tag name is not already in TagManager, create it, and link the Tag with the Picture.
   * @param tagsAfterName actual Tags in the past name
   */
  private void updateTagsFromPastName(String[] tagsAfterName) {
    for (int i = 1; i < tagsAfterName.length; i++) {
      Tag exists =
          TagManager.findThisTag(
              tagsAfterName[i].replace(
                  this.extension, "")); // for edge case - last string has the file extension.
      if (exists == null) {
        Tag newTag = TagManager.createTag(tagsAfterName[i].replace(this.extension, ""));
        this.addTag(newTag);
      } else {
        this.addTag(exists);
      }
    }
  }

  /**
   * Indicates whether some other object is "equal to" this one.
   * @param o the other Picture with which to compare.
   * @return returns true if this object is the same as the obj
   *          argument; returns false otherwise.
   */
  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (!(o instanceof Picture)) {
      return false;
    }
    Picture p = (Picture) o;
    return this.ID == p.getID() && this.ogFileAddress.equals(p.getOgFileAddress())
        && this.nameWithTags.equals(p.getNameWithTags());
  }

    /**
     * move the image file to specified path.
     * @param path destination location for the image file
     */
  void moveTo(String path) {
    String pastName = this.nameWithTags;
    this.nameWithTags = path + this.nameWithTags.substring(this.nameWithTags.lastIndexOf(File.separator));
    this.changeFileLocation(pastName, this.nameWithTags);
  }

    /**
     * moves the file to designated location, record the change.
     * @param older old name of the file
     * @param newer new name of the file
     */
  private void changeFileLocation(String older, String newer) {
    File file = new File(older);
    File newFile = new File(newer);
    if (!older.equals(newer)) {
      if (file.renameTo(newFile)) {
        TagManager.addToLog(older, newer);
        this.addPastName(older);
        this.setOgFileAddress(newer.substring(0, newer.lastIndexOf(File.separator) + 1));
        this.nameWithTags = newer;
      } else {
        View.LOGGER.log(Level.WARNING, String.format("FILE RENAME FAILED FOR <%s>", older));
      }
    }
  }

}
