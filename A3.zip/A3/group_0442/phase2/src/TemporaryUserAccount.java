public class TemporaryUserAccount extends UserAccount{
    public static int nextAccountNum = 1;

    public TemporaryUserAccount(){
        nextAccountNum += 1;
    }
}
