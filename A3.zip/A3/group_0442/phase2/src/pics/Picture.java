package pics;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javafx.collections.ObservableList;
import tags.*;
import utils.LogManager;

/**
 * <h1>Picture </h1>
 *
 * The Picture class records the information about a picture with ogFileAddress, the picture's
 * current name and ID, etc.
 */
public class Picture implements Serializable {

  /**
   * The file path of this Picture (without the name)
   */
  private String ogFileAddress;

  /**
   * The file name of the Picture without tags
   */
  private String name;

  /**
   * The full name of the Picture (includes file path)
   */
  private String nameWithTags;

  /**
   * The Picture file's extension
   */
  private String extension;

  /**
   * The Picture's ID, which dictates its position in PictureManager
   */
  private int ID;

  /**
   * an ArrayList of the Tags this Picture is currently tagged with.
   */
  private ArrayList<Tag> arrayTagsUsed;

  /**
   * An ArrayList of past full names of this Picture.
   */
  private ArrayList<String> arrayPastNames;

  /**
   * Constructs a Picture with the given file address.
   *
   * @param address the file path of the picture
   * @param ID the unique integer identifier of this Picture in PictureManager.PicStorage
   */
  public Picture(String address, int ID) {
    this.nameWithTags = address;
    revertToPrevious(address);
    this.arrayPastNames = new ArrayList<>();
    this.ID = ID;
  }

  /**
   * Getter method for this.nameWithTags.
   *
   * @return getNameWithTags() returns the current name of the Picture.
   */
  public String getNameWithTags() {
    return this.nameWithTags;
  }

  /**
   * Getter method for the this.ID of the Picture.
   *
   * @return an Integer ID of the Picture.
   */
  public int getID() {
    return this.ID;
  }

  /**
   * Getter method for this.ogFileAddress
   *
   * @return a String of the original file address
   */
  public String getOgFileAddress() {
    return this.ogFileAddress;
  }

  /**
   * Setter method for this.ogFileAddress.
   *
   * @param address String to set this.ogFileAddress
   */
  private void setOgFileAddress(String address) {
    this.ogFileAddress = address;
  }

  /**
   * Getter method for this.extension
   *
   * @return a String of the original file's extension
   */
  public String getExtension() {
    return extension;
  }

  /**
   * getter method for this.name
   *
   * @return a String of the original file's name (without tags)
   */
  public String getName() {
    return name;
  }

  /**
   * getter method for this.ArrayTagsUsed
   *
   * @return an ArrayList of Tags belonging to this Picture object
   */
  public ArrayList<Tag> getArrayTagsUsed() {
    return arrayTagsUsed;
  }

  /**
   * getter method for this.ArrayPastNames
   *
   * @return an ArrayList of past filenames (strings) for this Picture jbject
   */
  public ArrayList<String> getArrayPastNames() {
    return arrayPastNames;
  }

  /**
   * Adds Tag t to the Picture's (ArrayList)arrayTagsUsed.
   *
   * @param t Tag to be added.
   */
  public void addTag(Tag t) {
    if (!this.arrayTagsUsed.contains(t)) {
      this.arrayTagsUsed.add(t);
    }
  }

  /**
   * Adds all Tags in the parameter to the Picture's arrayTagsUsed.
   *
   * @param contenders list of Tags that will be added.
   */
  public void addTags(List<Tag> contenders) {
    for (Tag t : contenders) {
      if (!this.arrayTagsUsed.contains(t)) {
        this.arrayTagsUsed.add(t);
      }
    }
    this.rename();
  }

  /**
   * Removes all Tags in the parameter from this Picture's arrayTagsUsed.
   *
   * @param removables list of Tags to be removed from this Picture
   */
  public void removeTags(List<Tag> removables) {
    for (Tag t : removables) {
      if (t != null) {
        if (this.arrayTagsUsed.contains(t)) {
          this.arrayTagsUsed.remove(t);
        }
      }
    }
    this.rename();
  }

  /**
   * Adds the name to its arrayPastNames.
   *
   * @param name name to be added.
   */
  private void addPastName(String name) {
    if (!this.arrayPastNames.contains(name)) {
      this.arrayPastNames.add(name);
    }
  }

  /**
   * Renames the name of the Picture object according to its original name, Tag's in arrayTagsUsed
   * and extension. If the renaming is a success, add the previous name to arrayPastNames, log the
   * success. If a failure, log the failure
   */
  public void rename() {
    StringBuilder tags = new StringBuilder();
    for (Tag t : this.arrayTagsUsed) {
      tags.append(" ");
      tags.append(t.toString());
    }
    String pastName = this.nameWithTags;
    this.nameWithTags = this.ogFileAddress + this.name + tags + this.extension;
    this.changeFileLocation(pastName, this.nameWithTags);
  }

  /**
   * Returns a String representation of the Picture
   *
   * @return String representation of the Picture
   */
  public String toString() {
    return "a Picture: " + this.nameWithTags;
  }

  /**
   * Opens the directory that contains the current Picture in Using the file explorer provided by
   * the Operating System.
   */
  public void openInOS() {
    if (Desktop.isDesktopSupported()) {
      new Thread(
          () -> {
            try {
              Desktop.getDesktop().open(new File(this.ogFileAddress));
            } catch (IOException e) {
              e.printStackTrace();
            }
          })
          .start();
    }
  }

  /**
   * Helper method that extracts this.name from fileName
   *
   * @param fileName path name to extract this.name from
   * @return name of the file(without extension or Tags)
   */
  private String obtainNameFromFileName(String fileName) {
    String rawName =
        fileName.substring(
            fileName.lastIndexOf(File.separator) + 1,
            fileName.indexOf(this.extension)); // only file name
    String[] rawNameSplit = rawName.split(" @");
    return rawNameSplit[0].replace(this.extension, "");
  }

  /**
   * Helper method that extracts this.name from fileName
   *
   * @param fileName path name to extract this.extension from
   * @return extension of the fileName
   */
  private String obtainExtensionFromFileName(String fileName) {
    return "." + fileName.substring(fileName.lastIndexOf('.') + 1);
  }

  /**
   * Change the current name nameWithTags and arrayTagsUsed of the Picture back to the name
   * 'previous'.
   *
   * @param fileName a past name that the Picture will change back to.
   */
  public void revertToPrevious(String fileName) {
    // slice fileName into directory and fileNameWithoutDirectory.
    String directory = fileName.substring(0, fileName.lastIndexOf(File.separator) + 1);
    String fileNameWithoutDirectory =
        fileName.substring(fileName.lastIndexOf(File.separator) + 1, fileName.length());
    // split fileNameWithoutDirectory up with " @"
    String[] tagsAfterName = fileNameWithoutDirectory.split(" @");

    this.setOgFileAddress(directory);
    this.extension = obtainExtensionFromFileName(fileName); // eg. '.jpg'
    this.name = obtainNameFromFileName(fileName);
    // reconstruct arrayTagsUsed with the given fileName.
    this.arrayTagsUsed = new ArrayList<>();
    if (!(tagsAfterName[0].equals(
        this.extension))) { // check if extension is the only thing after this.name, if it is, that
      // means no Tags
      // in fileName, if no, that means the fileName contains Tags and we will update it into the
      // list)
      updateTagsFromList(Arrays.copyOfRange(tagsAfterName, 1, tagsAfterName.length));
    }
    this.rename();
  }

  /**
   * Helper for Picture.revertToPrevious(), reads Tags in the parameter into this.arrayTagsUsed
   *
   * @param tagsAfterName actual Tags in the past name
   */
  private void updateTagsFromList(String[] tagsAfterName) {
    for (String s : tagsAfterName) {
      String currentTagName = s
          .replace(this.extension, ""); // for edge case - last string has the file extension.
      Tag exists = TagManager.findThisTag(currentTagName);
      if (exists == null) {
        Tag newTag = TagManager.createTag(currentTagName);
        this.addTag(newTag);
      } else {
        this.addTag(exists);
      }
    }
  }

  /**
   * Indicates whether some other object is "equal to" this one.
   *
   * @param o the other Picture with which to compare.
   * @return returns true if this object is the same as the obj argument; returns false otherwise.
   */
  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (!(o instanceof Picture)) {
      return false;
    }
    Picture p = (Picture) o;
    return this.ID == p.getID()
        && this.ogFileAddress.equals(p.getOgFileAddress())
        && this.nameWithTags.equals(p.getNameWithTags());
  }

  /**
   * move the image file to specified path.
   *
   * @param path destination location for the image file
   */
  public void moveTo(String path) {
    String pastName = this.nameWithTags;
    String newName =
        path + this.nameWithTags.substring(this.nameWithTags.lastIndexOf(File.separator));
    this.changeFileLocation(pastName, newName);
  }

  /**
   * moves the file to designated location, record the change.
   *
   * @param older old name of the file
   * @param newer new name of the file
   */
  private void changeFileLocation(String older, String newer) {
    File file = new File(older);
    File newFile = new File(newer);
    if (!older.equals(newer)) {
      if (file.renameTo(newFile)) {
        LogManager.recordNameChange(older, newer);
        this.addPastName(older);
        this.setOgFileAddress(newer.substring(0, newer.lastIndexOf(File.separator) + 1));
        this.nameWithTags = newer;
      } else {
        LogManager.recordFailure(older);
      }
    }
  }

  /**
   * Checks if this Picture is tagged with all tags in the parameter.
   *
   * @param names ObservableList of Tags to compare with the Tags in this Picture
   * @return true iff this Picture contains all the Tags in the specified parameter else false
   */
  public boolean containsTags(ObservableList<Tag> names) {
    return arrayTagsUsed.containsAll(names);
  }
}
