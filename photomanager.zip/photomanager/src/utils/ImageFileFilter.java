package utils;

import java.io.*;

/**
 * credit to: https://alvinalexander.com/blog/post/java/how-implement-java-filefilter-list-files-directory
 *
 * <p>A class that implements the Java FileFilter interface.
 */
public class ImageFileFilter implements FileFilter {

  private final String[] okFileExtensions = new String[]{"jpg", "png"};

  public boolean accept(File file) {
    if (file.isDirectory()) {
      return true;
    }
    for (String extension : okFileExtensions) {
      if (file.getName().toLowerCase().endsWith(extension)) {
        return true;
      }
    }
    return false;
  }
}

