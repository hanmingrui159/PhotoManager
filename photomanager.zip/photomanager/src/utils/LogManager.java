package utils;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.SimpleFormatter;

public class LogManager {

  private final static java.util.logging.Logger LOGGER = java.util.logging.Logger
            .getLogger("MyLog");

  public void startup() {
    try { //start up the log
      FileHandler fh = new FileHandler("MyLog.log", true);
      LOGGER.addHandler(fh);
      SimpleFormatter formatter = new SimpleFormatter();
      fh.setFormatter(formatter);
      LOGGER.info("=== STARTED PROGRAM ===");
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  /**
   * Add rename information to Log.
   *
   * @param old the old name of a picture.
   * @param cur the new name of a picture.
   */
  public static void recordNameChange(String old, String cur) {
    LOGGER.info(String.format("RENAMED:  <%s>  TO  <%s>", old, cur) +
        System.lineSeparator());
  }

  public static void recordFailure(String oldName) {
          LOGGER.log(Level.WARNING, String.format("FILE RENAME FAILED FOR <%s>", oldName));
  }

  public void close() {
    for (Handler h : LOGGER.getHandlers()) {
      h.close();
    }
  }

  public void openLog() {
    if (Desktop.isDesktopSupported()) {
      new Thread(() -> {
        try {
          Desktop.getDesktop().open(new File("MyLog.log"));
        } catch (IOException e) {
          e.printStackTrace();
        }
      }).start();
    }
  }


}
