public class Run {
  public static void main(String[] args) {
      System.out.println("UserAccount.nextAccountNum = "+UserAccount.nextAccountNum);


      UserAccount a = new UserAccount();
      System.out.println("b = "+ a.b);
      System.out.println("UserAccount.nextAccountNum = "+UserAccount.nextAccountNum);
      System.out.println("TemporaryUserAccount.nextAccountNum = "+TemporaryUserAccount.nextAccountNum);

      TemporaryUserAccount c = new TemporaryUserAccount();

    System.out.println("UserAccount.nextAccountNum = "+UserAccount.nextAccountNum);
    System.out.println("TemporaryUserAccount.nextAccountNum = "+TemporaryUserAccount.nextAccountNum);

  }
}
