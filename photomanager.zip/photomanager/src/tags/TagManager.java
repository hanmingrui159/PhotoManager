package tags;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * <h1> TagManager </h1> The TagManager program implements an application that manages Tag objects.
 * <p> The TagManager can add, delete, find Tags and save Tags to, read Tags from files.
 */
public class TagManager implements Serializable {

  /**
   * An ArrayList of Tags. Used for reading/writing to file operations.
   */
  private static ArrayList<Tag> arrayListOfTags = new ArrayList<>();

  /**
   * Creates a Tag object with given name.
   *
   * @param name the name of the created Tag.
   * @return the created Tag.
   */
  public static Tag createTag(String name) {
    Tag a = new Tag(name);
    arrayListOfTags.add(a);
    return a;
  }

  /**
   * Deletes all Tags in the parameter
   *
   * @param begone a list of Tags to be deleted
   */
  public static void deleteTags(List<Tag> begone) {
    if (begone != null) {
      ArrayList<Tag> copy = new ArrayList<>();
      for (Tag t : begone) {
        copy.add(new Tag(t));
      }
      for (Tag t : copy) {
        if (arrayListOfTags.contains(t)) {
          arrayListOfTags.remove(t);
        }
      }
    }
  }

  /**
   * Save existing Tags to a file
   *
   * @param path the path where the file is
   * @throws IOException if the path doesn't exist
   */
  public static void saveToFile(String path) throws IOException {
    OutputStream file = new FileOutputStream(path);
    OutputStream buffer = new BufferedOutputStream(file);
    ObjectOutput output = new ObjectOutputStream(buffer);

    output.writeObject(arrayListOfTags);
    output.close();
  }

  /**
   * Read Tags from a given file
   *
   * @param path the path of the file.
   * @throws ClassNotFoundException if there's no required file under the given path.
   */
  @SuppressWarnings("unchecked")
  public static void readFromFile(String path) throws ClassNotFoundException {
    try {
      InputStream file = new FileInputStream(path);
      InputStream buffer = new BufferedInputStream(file);
      ObjectInput input = new ObjectInputStream(buffer);

      arrayListOfTags = (ArrayList<Tag>) input.readObject();
      input.close();

    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  /**
   * Find the Tag with given name.
   *
   * @param name the name of a potential Tag.
   * @return the Tag with given name if it exists; null otherwise.
   */
  public static Tag findThisTag(String name) {
    for (Tag t : arrayListOfTags) {
      if (t.getName().equals(name)) {
        return t;
      }
    }
    return null;
  }

  /**
   * getter method for TagManager.arrayListOfTags
   *
   * @return an ArrayList of all Tags
   */
  public static ArrayList getArrayListOfTags() {
    return arrayListOfTags;
  }


}