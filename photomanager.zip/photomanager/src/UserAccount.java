class UserAccount {
    public static int nextAccountNum = 1;
    public int b;

    public UserAccount(){
        b= nextAccountNum++;
    }
}
