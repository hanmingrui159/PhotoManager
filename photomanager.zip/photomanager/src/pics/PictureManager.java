package pics;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import javafx.collections.ObservableList;
import tags.*;
import utils.ImageFileFilter;

/**
 * <h1>PictureManager </h1>
 *
 * PictureManager object stores a HashMap of Pictures with their unique Integer ID. Its storage of
 * Pictures can be saved to local files and read when the program reopens later.
 */
public class PictureManager {

  /**
   * a counting variable which assigns a unique integer value to each tracked picture
   */
  private static int picID = 0;

  /**
   * Stores all tracked pictures with their corresponding unique identifier
   */
  private static HashMap<Integer, Picture> PicStorage = new HashMap<>();

  /**
   * Saves the HashMap of Pictures to a local file with the file path specified in the parameter.
   *
   * @param path file path that the HashMap of Pictures to be saved at.
   * @throws IOException the Exception is thrown when failure of saving occurs when the directory
   * containing the file path doesn't exist
   */
  public static void saveToFile(String path) throws IOException {
    OutputStream file = new FileOutputStream(path);
    OutputStream buffer = new BufferedOutputStream(file);
    ObjectOutput output = new ObjectOutputStream(buffer);

    output.writeObject(PictureManager.PicStorage);
    output.close();
  }

  /**
   * Reads the saved file of Pictures back to the PictureManager's HashMap
   * PictureManager.PicStorage
   *
   * @param path path of the saved file to be read from
   * @throws ClassNotFoundException Exception is thrown when the designated file does not exist or
   * the directory does not exist.
   */
  @SuppressWarnings("unchecked")
  public static void readFromFile(String path) throws ClassNotFoundException {
    try {
      InputStream file = new FileInputStream(path);
      InputStream buffer = new BufferedInputStream(file);
      ObjectInput input = new ObjectInputStream(buffer);

      PictureManager.PicStorage = (HashMap<Integer, Picture>) input.readObject();
      input.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  /**
   * Creates a new Picture, put it into PicStorage, and return the created Picture
   *
   * @param address file address of the new Picture
   * @return the newly created Picture object
   */
  public static Picture createPicture(String address) {
    Picture newPicture = new Picture(address, picID);
    PictureManager.putPic(picID, newPicture); // stores object in hashmap
    PictureManager.incPicID(); // increases picID to keep it unique
    return newPicture;
  }

  /**
   * Searches through all tracked pictures and finds ones that are tagged with all tags in the
   * parameter.
   *
   * @param tags the tags to search for in all tracked images
   * @return an ArrayList of Pictures that contain all the tags in the parameter
   */
  public static ArrayList<Picture> findPicsWithTags(ObservableList<Tag> tags) {
    HashSet<Picture> picsWithTags = new HashSet<>();
    for (int k : PicStorage.keySet()) {
      if (PicStorage.get(k).containsTags(tags)) {
        picsWithTags.add(PicStorage.get(k));
      }
    }
    return new ArrayList<>(picsWithTags);
  }

  /**
   * Recursively combs through the directory specified in the parameter and tracks all pictures
   * within the specified directory and its subdirectories. Adds all Tags the pictures may contain
   * to the global tag set.
   *
   * @param directory the directory in which to search for pictures
   * @param pics an ArrayList to keep track of all found pictures
   * @return returns an ArrayList of all Pictures in and under the directory specified in the
   * parameter.
   */
  public static ArrayList<Picture> getPicturesUnderPath(File directory, ArrayList<Picture> pics) {
    if (directory != null) {
      ImageFileFilter imageFileFilter = new ImageFileFilter();
      File[] files =
          directory.listFiles(
              imageFileFilter); // get a list of files with .jpg or .png as extensions
      if (files != null) {
        outer:
        for (File file : files) {
          if (file.isDirectory()) {
            ArrayList<Picture> temp = getPicturesUnderPath(file, pics); // Calls same method again.
            HashSet<Picture> a = new HashSet<>(pics);
            HashSet<Picture> b = new HashSet<>(temp);
            a.addAll(b);
            pics = new ArrayList<>(a);
          } else { // is an image file
            for (Integer k : PicStorage.keySet()) { // check if already existing in PicStorage
              if (PicStorage.get(k).getNameWithTags().equals(file.getAbsolutePath())) {
                // adds all tags in the Picture to the global list of tags
                PicStorage.get(k).revertToPrevious(PicStorage.get(k).getNameWithTags());
                pics.add(PicStorage.get(k));
                continue outer;
              }
            }
            Picture newPicture = createPicture(
                file.getAbsolutePath()); // create new picture if not already existing
            pics.add(newPicture);
          }
        }
      }
    }
    return pics;
  }

  /**
   * getter method for picID
   *
   * @return the integer picID
   */
  public static int getPicID() {
    return picID;
  }

  /**
   * incrementing method for picID, increases picID by 1
   */
  private static void incPicID() {
    picID++;
  }

  /**
   * getter method for a Picture stored in PicStorage
   *
   * @param ID the unique ID of a Picture in PicStorage
   * @return the Picture object corresponding to the parameter's identifier
   */
  public static Picture getPic(int ID) {
    return PicStorage.get(ID);
  }

  /**
   * setter method for a new Picture to be stored in PicStorage
   *
   * @param ID the unique ID of the Picture to be stored.
   * @param p the Picture object to be stored.
   */
  private static void putPic(int ID, Picture p) {
    PicStorage.put(ID, p);
  }

  /**
   * getter method for the keys of PicStorage
   *
   * @return the Set of integers that make up all the unique identifiers for all Pictures in
   * PicStorage
   */
  public static Set<Integer> getKeySet() {
    return PicStorage.keySet();
  }
}
