package tests;

import java.util.ArrayList;
import org.junit.jupiter.api.Test;
import java.io.File;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;

import tags.*;

class TagManagerTest {

  @Test
  void testCreateTag() {
    Tag a = new Tag("test");
    Tag b = new Tag("t");
    Tag c = new Tag("c");

    assertEquals(b, TagManager.createTag("t"));
    assertEquals(a, TagManager.createTag("test"));

    assertEquals(true, TagManager.getArrayListOfTags().contains(a));
    assertEquals(true, TagManager.getArrayListOfTags().contains(b));
    assertEquals(false, TagManager.getArrayListOfTags().contains(c));
  }

  @Test
  void testDeleteTag() {
    Tag a = new Tag("test1");
    Tag b = new Tag("b1");

    TagManager.createTag("test1");
    TagManager.createTag("b1");

    ArrayList<Tag> deletes = new ArrayList<>();
    deletes.add(a);
    TagManager.deleteTags(deletes);

    assertEquals(false, TagManager.getArrayListOfTags().contains(a));
    assertEquals(true, TagManager.getArrayListOfTags().contains(b));
  }

  @Test
  void testSaveToFile() {
    Tag a = new Tag("test2");
    Tag b = new Tag("b2");
    Tag c = new Tag("c1");

    TagManager.createTag("test2");
    TagManager.createTag("b2");

    try {
      TagManager.saveToFile("tagSaveTest.ser");
    } catch (IOException e) {
      e.printStackTrace();
    }

    try {
      TagManager.readFromFile("tagSaveTest.ser");
    } catch (ClassNotFoundException e1) {
      e1.printStackTrace();
    }

    assertEquals(true, TagManager.getArrayListOfTags().contains(a));
    assertEquals(true, TagManager.getArrayListOfTags().contains(b));
    assertEquals(false, TagManager.getArrayListOfTags().contains(c));

    File f = new File("tagSaveTest.ser");
    f.delete();
  }


  @Test
  void testReadFromFile() {
    Tag a = new Tag("test3");
    Tag b = new Tag("b3");
    Tag c = new Tag("c2");
    TagManager.createTag("test3");
    TagManager.createTag("b3");

    try {
      TagManager.saveToFile("tagSaveTest.ser");
    } catch (IOException e) {
      e.printStackTrace();
    }

    try {
      TagManager.readFromFile("tagSaveTest.ser");
    } catch (ClassNotFoundException e1) {
      e1.printStackTrace();
    }

    assertEquals(true, TagManager.getArrayListOfTags().contains(a));
    assertEquals(true, TagManager.getArrayListOfTags().contains(b));
    assertEquals(false, TagManager.getArrayListOfTags().contains(c));

    File f = new File("tagSaveTest.ser");
    f.delete();
  }


  @Test
  void testFindThisTag() {
    Tag a = new Tag("test4");
    Tag b = new Tag("b4");

    TagManager.createTag("test4");
    TagManager.createTag("b4");

    assertEquals(a, TagManager.findThisTag("test4"));
    assertEquals(b, TagManager.findThisTag("b4"));
    assertEquals(null, TagManager.findThisTag("dfd"));
  }

}
