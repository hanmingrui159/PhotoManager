package tests;

import java.io.File;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import pics.*;
import tags.*;

class PictureTest {

  private Picture picture1;
  private Picture picture2;
  private Picture picture3;

  @BeforeEach
  void setUp() {
    picture1 = PictureManager.createPicture("testData" + File.separator + "gardens.jpg");
    picture2 = PictureManager.createPicture("testData" + File.separator + "universe @a @aa.jpg");
    picture3 = PictureManager.createPicture("testData" + File.separator + ".jpg");
  }

  @AfterEach
  void tearDown() {

  }

  //
  // testing constructor case for picture1
  //
  @Test
  void shouldReturnFolderAddressTest1() {
    assertEquals("testData" + File.separator, picture1.getOgFileAddress());
  }

  @Test
  void shouldReturnAddressTest1() {

    assertEquals("testData" + File.separator + "gardens.jpg", picture1.getNameWithTags());
  }

  @Test
  void shouldReturnExtensionTest1() {
    assertEquals(".jpg", picture1.getExtension());
  }

  @Test
  void shouldReturnNameTest1() {
    assertEquals("gardens", picture1.getName());
  }

  @Test
  void shouldReturnArrayTagsUsedTest1() {
    assertEquals(new ArrayList(), picture1.getArrayTagsUsed());
  }

  @Test
  void shouldReturnArrayPastNamesTest1() {
    assertEquals(new ArrayList(), picture1.getArrayPastNames());
  }

  @Test
  void shouldBeInCorrectPairInPicManager1() {
    assertEquals(picture1, PictureManager.getPic(picture1.getID()));
  }

  //
  // testing constructor case for picture2
  //
  @Test
  void shouldReturnFolderAddressTest2() {
    assertEquals("testData" + File.separator, picture2.getOgFileAddress());
  }

  @Test
  void shouldReturnAddressTest2() {

    assertEquals("testData" + File.separator + "universe @a @aa.jpg", picture2.getNameWithTags());
  }

  @Test
  void shouldReturnExtensionTest2() {
    assertEquals(".jpg", picture2.getExtension());
  }

  @Test
  void shouldReturnNameTest2() {
    assertEquals("universe", picture2.getName());
  }

  @Test
  @SuppressWarnings("unchecked")
  void shouldReturnArrayTagsUsedTest2() {
    ArrayList expected = new ArrayList();
    expected.add(new Tag("a"));
    expected.add(new Tag("aa"));

    assertEquals(expected, picture2.getArrayTagsUsed());
  }

  @Test
  void shouldReturnArrayPastNamesTest2() {

    assertEquals(new ArrayList<>(), picture2.getArrayPastNames());
  }

  @Test
  void shouldBeInCorrectPairInPicManager2() {
    assertEquals(picture2, PictureManager.getPic(picture2.getID()));
  }

  //
  // testing constructor case for picture3
  //
  @Test
  void shouldReturnFolderAddressTest3() {
    assertEquals("testData" + File.separator, picture3.getOgFileAddress());
  }

  @Test
  void shouldReturnAddressTest3() {
    assertEquals("testData" + File.separator + ".jpg", picture3.getNameWithTags());
  }

  @Test
  void shouldReturnExtensionTest3() {
    assertEquals(".jpg", picture3.getExtension());
  }

  @Test
  void shouldReturnNameTest3() {
    assertEquals("", picture3.getName());
  }

  @Test
  void shouldReturnArrayTagsUsedTest3() {
    assertEquals(new ArrayList(), picture3.getArrayTagsUsed());
  }

  @Test
  void shouldReturnArrayPastNamesTest3() {
    assertEquals(new ArrayList(), picture3.getArrayPastNames());
  }


  @Test
  void shouldBeInCorrectPairInPicManager3() {
    assertEquals(picture3, PictureManager.getPic(picture3.getID()));
  }


  @Test
  @SuppressWarnings("unchecked")
  void testAddTag() {

    final Tag tagA = new Tag("A");
    picture1.addTag(tagA);
    ArrayList tagsExpected = new ArrayList();
    tagsExpected.add(tagA);
    assertEquals(tagsExpected, picture1.getArrayTagsUsed());
  }

  @Test
  @SuppressWarnings("unchecked")
  void testRemoveTag() {
    final Tag tagA = new Tag("A");
    picture1.addTag(tagA);
    ArrayList removal = new ArrayList<>();
    removal.add(tagA);
    picture1.removeTags(removal);
    assertEquals(new ArrayList(), picture1.getArrayTagsUsed());

  }

  @Test
  void testRename1() {
    final Tag tagA = new Tag("A");
    picture1.addTag(tagA);
    picture1.rename();

    assertEquals("testData" + File.separator + "gardens @A.jpg", picture1.getNameWithTags());
    picture1.revertToPrevious("testData" + File.separator + "gardens.jpg");
  }

  @Test
  void testRename2() {
    final Tag tagA = new Tag("A");
    final Tag tagB = new Tag("B");
    picture2.addTag(tagA);
    picture2.addTag(tagA);
    picture2.addTag(tagB);
    picture2.rename();

    assertEquals("testData" + File.separator + "universe @a @aa @A @B.jpg",
        picture2.getNameWithTags());
    picture2.revertToPrevious("testData" + File.separator + "universe @a @aa.jpg");
  }

  @Test
  void testRename3() {
    final Tag tagA = new Tag("A");
    final Tag tagB = new Tag("B");
    picture3.addTag(tagA);
    picture3.addTag(tagA);
    picture3.addTag(tagB);
    picture3.rename();

    assertEquals("testData" + File.separator + " @A @B.jpg", picture3.getNameWithTags());
    picture3.revertToPrevious("testData" + File.separator + ".jpg");
  }

  @Test
  @SuppressWarnings("unchecked")
  void testPastName() {
    final Tag tagA = new Tag("A");
    picture1.addTag(tagA);
    picture1.rename();

    ArrayList namesExpected = new ArrayList();
    namesExpected.add("testData" + File.separator + "gardens.jpg");

    assertEquals(namesExpected, picture1.getArrayPastNames());
  }

  @Test
  void testToString() {
    assertEquals("a Picture: testData" + File.separator + "gardens.jpg", picture1.toString());
  }

  @Test
  void testRevertToPrevious() {
    final Tag tag1 = new Tag("A");
    final Tag tag2 = new Tag("B");
    final Tag tag3 = new Tag("C");
    final Tag tag4 = new Tag("D");
    final Tag tag5 = new Tag("E");

    picture1.addTag(tag1);
    picture1.addTag(tag2);
    picture1.addTag(tag3);
    picture1.addTag(tag4);
    picture1.addTag(tag5);
    picture1.rename();

    picture1.revertToPrevious("testData" + File.separator + "gardens.jpg");

    assertEquals("testData" + File.separator + "gardens.jpg", picture1.getNameWithTags());
    assertEquals(new ArrayList(), picture1.getArrayTagsUsed());
  }

  @Test
  void testEquals() {
    assertEquals(picture1, picture1);
    assertNotEquals(picture1, picture2);
    assertNotEquals(picture1, new Picture("testData/gardens.jpg", 0));

  }

  @Test
  void testEquals2() {
    assertEquals(picture2, picture2);
    assertNotEquals(picture3, picture2);
    assertNotEquals(picture3, new Picture("testData/gardens.jpg", -1));

  }

  @Test
  void testEquals3() {
    assertEquals(picture1, picture1);
    assertNotEquals(picture1, picture2);
    assertNotEquals(picture1, new Picture("testData/gardens.jpg", 0));
  }

  @Test
  void testContainsTags() {
    final Tag tag1 = new Tag("A");
    final Tag tag2 = new Tag("B");
    final Tag tag3 = new Tag("C");
    final Tag tag4 = new Tag("D");
    final Tag tag5 = new Tag("E");

    picture1.addTag(tag1);
    picture1.addTag(tag2);
    picture1.addTag(tag3);
    picture1.addTag(tag4);
    picture1.addTag(tag5);

    ObservableList<Tag> expectedContainedTags = FXCollections.observableArrayList();
    expectedContainedTags.addAll(tag1, tag2, tag3, tag4, tag5);
    assertTrue(picture1.containsTags(expectedContainedTags));
  }

  @Test
  void testMoveTo1() {
    picture1.moveTo("src");
    assertEquals("src" + File.separator + "gardens.jpg", picture1.getNameWithTags());
    picture1.revertToPrevious("testData" + File.separator + "gardens.jpg");
  }

  @Test
  void testMoveTo2() {

    picture2.moveTo("src");
    assertEquals("src" + File.separator + "universe @a @aa.jpg", picture2.getNameWithTags());

    picture2.revertToPrevious("testData" + File.separator + "universe @a @aa.jpg");
  }

  @Test
  void testMoveTo3() {
    picture3.moveTo("src");

    assertEquals("src" + File.separator + ".jpg", picture3.getNameWithTags());

    picture3.revertToPrevious("testData" + File.separator + ".jpg");
  }
}
