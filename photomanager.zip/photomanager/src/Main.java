import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import pics.*;
import tags.*;
import utils.LogManager;

public class Main extends Application {

  private int currentID = -1;
  private Image currentImage;

  private final String tagSaveLocation = "tagsave.ser";
  private final String pictureSaveLocation = "picturesave.ser";

  public static void main(String[] args) {
    launch(args);
  }

  @Override
  @SuppressWarnings("unchecked")
  public void start(Stage stage) {
    // if there is a saved file of tags/images, read from it.
    try {
      TagManager.readFromFile(tagSaveLocation);
    } catch (ClassNotFoundException e) {
      e.printStackTrace();
    }
    try {
      PictureManager.readFromFile(pictureSaveLocation);
    } catch (ClassNotFoundException e) {
      e.printStackTrace();
    }

    // start up the master log
    LogManager LOG = new LogManager();
    LOG.startup();

    BorderPane root = new BorderPane();
    BorderPane.setAlignment(root, Pos.CENTER);
    Scene scene = new Scene(root, 1000, 600);
    root.setMinWidth(600);
    root.setMinHeight(500);

    root.setPadding(new Insets(0, 10, 0, 10));
    MenuBar menuBar = new MenuBar();
    menuBar.prefWidthProperty().bind(stage.widthProperty());

    Menu fileMenu = new Menu("File...");
    MenuItem openPicItem = new MenuItem("Open Picture");
    MenuItem viewLogItem = new MenuItem("Open master log");
    MenuItem selectRootItem = new MenuItem("Select Root Directory");
    fileMenu.getItems().addAll(openPicItem, viewLogItem, selectRootItem);

    Menu addTagsMenu = new Menu();
    Label addTagsMenuLabel = new Label("Add selected tags");
    addTagsMenu.setGraphic(addTagsMenuLabel);
    Menu removeTagsMenu = new Menu();
    Label removeTagsMenuLabel = new Label("Remove selected tags");
    removeTagsMenu.setGraphic(removeTagsMenuLabel);

    Menu pictureOperationsMenu = new Menu("More Picture...");
    MenuItem movePicItem = new MenuItem("Move Picture location");
    MenuItem revertItem = new MenuItem("Revert to past name");
    MenuItem viewDirItem = new MenuItem("Open parent directory");
    pictureOperationsMenu.getItems().addAll(movePicItem, revertItem, viewDirItem);

    Menu createTagMenu = new Menu();
    Label createTagMenuLabel = new Label("Create Tag");
    createTagMenu.setGraphic(createTagMenuLabel);
    Menu deleteTagsMenu = new Menu();
    Label deleteTagsMenuLabel = new Label("Delete selected Tags");
    deleteTagsMenu.setGraphic(deleteTagsMenuLabel);

    Menu tagOperationsMenu = new Menu("More Tag...");
    MenuItem filterTagsItem = new MenuItem("Filter Pictures by Tags");
    tagOperationsMenu.getItems().addAll(filterTagsItem);

    menuBar.getMenus().addAll(fileMenu, addTagsMenu, removeTagsMenu, pictureOperationsMenu,
        createTagMenu, deleteTagsMenu, tagOperationsMenu);

    ListView<Tag> listOfAllTags = new ListView<>(); //all existing tags
    listOfAllTags.setEditable(false);
    listOfAllTags.setMaxWidth(200);
    listOfAllTags.setItems(FXCollections.observableArrayList(TagManager.getArrayListOfTags()));
    listOfAllTags.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

    ListView<Tag> listOfPictureTags = new ListView<>(); //tags belonging to the current image
    ObservableList<Tag> pictureTags = FXCollections.observableArrayList();
    listOfPictureTags.setEditable(false);
    listOfPictureTags.setMaxWidth(200);
    listOfPictureTags.setItems(pictureTags);
    listOfPictureTags.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

    ImageView iv = new ImageView(); //displays the image
    Text absolutePath = new Text("Open an image to begin");
    root.setTop(menuBar);
    root.setBottom(absolutePath);
    root.setCenter(iv);
    root.setLeft(listOfPictureTags);
    root.setRight(listOfAllTags);

    FileChooser fileChooser = new FileChooser(); // only show common image extensions
    FileChooser.ExtensionFilter imageFilter
        = new FileChooser.ExtensionFilter("Image Files", "*.jpg", "*.png");
    fileChooser.getExtensionFilters().add(imageFilter);

    // openPicItem: when clicked, opens up a file dialog allowing the user to
    // choose and open an image file in the program.
    openPicItem.setOnAction((event) -> {
      File file = fileChooser.showOpenDialog(stage);
      if (file != null) {
        currentImage = new Image("file:" + file.getAbsolutePath(), 500, 500, true, true);
        absolutePath.setText(file.getAbsolutePath());
        for (Integer k : PictureManager.getKeySet()) {
          if (PictureManager.getPic(k).getNameWithTags().equals(file.getAbsolutePath())) {
            iv.setImage(currentImage);
            currentID = k;
            listOfPictureTags.setItems(FXCollections
                .observableArrayList(PictureManager.getPic(k).getArrayTagsUsed()));
            listOfAllTags
                .setItems(FXCollections.observableArrayList(TagManager.getArrayListOfTags()));
            return;
          }
        }
        currentID = PictureManager.getPicID();
        PictureManager.createPicture(file.getAbsolutePath());
        listOfPictureTags.setItems(FXCollections
            .observableArrayList(PictureManager.getPic(currentID).getArrayTagsUsed()));
        listOfAllTags.setItems(FXCollections.observableArrayList(TagManager.getArrayListOfTags()));
        iv.setImage(currentImage);
      }
    });

    // viewLogItem: when clicked, opens the master log of the program,
    // which records all name changes to all tracked image files. The log is opened
    // text file which is opened external of the program.
    viewLogItem.setOnAction((event) -> LOG.openLog());

    // selectRootItem: when clicked, opens an external window which asks the user to choose
    // a directory. It then combs through the chosen directory and all of its subdirectories and
    // records all the tags of all images present in the global tag list. It also opens a window
    // displaying all image files in and below the chosen directory, and gives the user the option
    // to open one of the images in that display. The user also has the option to cancel this
    // operation and return to the main program.
    selectRootItem.setOnAction((event) -> {
      DirectoryChooser directoryChooser = new DirectoryChooser();
      File selectedDirectory = directoryChooser.showDialog(stage);
      if (selectedDirectory != null) {
        ArrayList<Picture> picList = PictureManager
            .getPicturesUnderPath(selectedDirectory, new ArrayList<>());
        listOfAllTags.setItems(FXCollections.observableArrayList(TagManager.getArrayListOfTags()));

        Stage newDirStage = new Stage();
        ListView<Picture> imagesUnderDirectoryList = new ListView<>();
        imagesUnderDirectoryList.setEditable(false);
        imagesUnderDirectoryList.setItems(FXCollections.observableArrayList(picList));
        imagesUnderDirectoryList.setPrefWidth(400);
        imagesUnderDirectoryList.setPrefHeight(700);
        imagesUnderDirectoryList.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);

        // tells imagesUnderDirectoryList to show a visual representation of each
        // of its Picture objects, along with their file name
        imagesUnderDirectoryList.setCellFactory(listView -> new ListCell<Picture>() {
          private final ImageView imageView = new ImageView();

          @Override
          public void updateItem(Picture p, boolean empty) {
            super.updateItem(p, empty);
            if (empty) {
              setText(null);
              setGraphic(null);
            } else {
              setText(p.getNameWithTags());
              imageView
                  .setImage(new Image("file:" + p.getNameWithTags(), 100, 80, true, true, true));
              setGraphic(imageView);
            }
          }
        });
        imagesUnderDirectoryList.setMinWidth(200);

        // selectBtn: opens the selected image in the main program
        Button selectBtn = new Button("Open in program");
        selectBtn.setOnAction((selectEvent) -> {
          Picture p = imagesUnderDirectoryList.getSelectionModel().getSelectedItem();
          if (p != null) {
            currentID = p.getID();
            currentImage = new Image("file:" + p.getNameWithTags(), 500, 500, true, true);
            iv.setImage(currentImage);
            absolutePath.setText(p.getNameWithTags());
            listOfPictureTags.setItems(FXCollections
                .observableArrayList(p.getArrayTagsUsed()));
            listOfAllTags
                .setItems(FXCollections.observableArrayList(TagManager.getArrayListOfTags()));
          }
          newDirStage.close();
        });
        // opens selected image's parent directory in the OS-specific file manager.
        Button parentBtn = new Button("Open location in directory");
        parentBtn.setOnAction((parentEvent) -> {
          Picture p = imagesUnderDirectoryList.getSelectionModel().getSelectedItem();
          if (p != null) {
            p.openInOS();
          }
        });

        Button cancelBtn = new Button("Cancel");
        cancelBtn.setOnAction((cancelEvent) -> newDirStage.close());

        HBox btnBox = new HBox(selectBtn, parentBtn, cancelBtn);
        btnBox.setSpacing(10);
        VBox layout = new VBox(btnBox, imagesUnderDirectoryList);
        layout.setPadding(new Insets(10));
        newDirStage.setScene(new Scene(layout));
        newDirStage.show();
      }
    });

    // addTagsMenuLabel: when clicked, takes all the selected tags from the global tag list and
    // adds them to the currently opened picture. It then renames the picture with the new tags.
    addTagsMenuLabel.setOnMouseClicked((event) -> {
      ObservableList<Tag> contenders = listOfAllTags.getSelectionModel().getSelectedItems();
      if (currentID != -1 && contenders != null) {
        PictureManager.getPic(currentID).addTags(contenders);

        listOfPictureTags.setItems(FXCollections
            .observableArrayList(PictureManager.getPic(currentID).getArrayTagsUsed()));
        absolutePath.setText(PictureManager.getPic(currentID).getNameWithTags());
      }
    });

    // removeTagsMenuLabel: when clicked, removes all the selected tags from the current picture's
    // list of tags and removes them from the picture. It then renames the picture without the
    // removed tags.
    removeTagsMenuLabel.setOnMouseClicked((event) -> {
      ObservableList<Tag> removables = listOfPictureTags.getSelectionModel().getSelectedItems();
      if (currentID != -1 && removables != null) {
        PictureManager.getPic(currentID).removeTags(removables);

        listOfPictureTags.setItems(FXCollections
            .observableArrayList(PictureManager.getPic(currentID).getArrayTagsUsed()));
        absolutePath.setText(PictureManager.getPic(currentID).getNameWithTags());
      }
    });

    // movePicItem: when clicked, opens a program window which asks the user to
    // choose a directory to which the currently opened picture is moved, then moves the picture.
    // The user also has the option to cancel this operation and return to the main program.
    movePicItem.setOnAction((event) -> {
      if (currentID != -1) {
        DirectoryChooser directoryChooser = new DirectoryChooser();
        File selectedDirectory = directoryChooser.showDialog(stage);
        if (selectedDirectory != null) {
          PictureManager.getPic(currentID).moveTo(selectedDirectory.getAbsolutePath());
          absolutePath.setText(PictureManager.getPic(currentID).getNameWithTags());
        }
      }
    });

    // revertItem: when clicked, opens a program window which asks the user to choose
    // one of the current picture's past names (and corresponding past tag set). It then changes the
    // current picture's name and tag set back to what the user picked. The user also has the
    // option to cancel this operation and return to the main program.
    revertItem.setOnAction((event) -> {
      if (currentID != -1) {
        Stage revertStage = new Stage();
        ListView<String> listOfRevertTags = new ListView<>(); //all existing tags
        listOfRevertTags.setEditable(false);
        listOfRevertTags.setItems(FXCollections
            .observableArrayList(PictureManager.getPic(currentID).getArrayPastNames()));
        listOfRevertTags.setMaxHeight(500);

        Button selectBtn = new Button("Revert to this name");
        selectBtn.setOnAction((eventSelect) -> {
          String revertToMe = listOfRevertTags.getSelectionModel().getSelectedItem();
          if (revertToMe != null) {
            PictureManager.getPic(currentID).revertToPrevious(revertToMe);

            listOfPictureTags.setItems(FXCollections
                .observableArrayList(PictureManager.getPic(currentID).getArrayTagsUsed()));
            listOfAllTags
                .setItems(FXCollections.observableArrayList(TagManager.getArrayListOfTags()));
            absolutePath.setText(PictureManager.getPic(currentID).getNameWithTags());
          }
          revertStage.close();
        });
        Button cancelBtn = new Button("Cancel");
        cancelBtn.setOnAction((eventCancel) -> revertStage.close());

        GridPane revertPane = new GridPane();
        revertPane.setHgap(8);
        revertPane.setVgap(8);
        revertPane.setPadding(new Insets(10, 10, 10, 10));
        revertPane.add(listOfRevertTags, 1, 0, 2, 1);
        revertPane.add(selectBtn, 0, 0);
        revertPane.add(cancelBtn, 0, 1);
        Scene newTagScene = new Scene(revertPane);
        revertStage.setScene(newTagScene);
        revertStage.show();
      }
    });

    // viewDirItem: when clicked, opens (externally) the folder of the current picture in the
    // file manager of the user's operating system.
    viewDirItem.setOnAction((event) -> {
      if (currentID != -1) {
        PictureManager.getPic(currentID).openInOS();
      }
    });

    // createTagMenuLabel: when clicked, opens a program window which asks the user to input the
    // name of a new Tag the user would like to create. It then creates the tag with the user's
    // input and adds it to the global tag set. The user also has the option to cancel
    // this operation and return to the main program.
    createTagMenuLabel.setOnMouseClicked((event) -> {
      Stage newTagStage = new Stage();
      TextField textUser = new TextField();
      textUser.setPromptText("Enter name of new Tag.");
      Button okBtn = new Button("Create");
      okBtn.setOnAction((eventOK) -> {
        String txt = textUser.getText().trim();
        if (TagManager.findThisTag(txt) == null) {
          TagManager.createTag(txt);
          listOfAllTags
              .setItems(FXCollections.observableArrayList(TagManager.getArrayListOfTags()));
        }
        newTagStage.close();
      });

      Button cancelBtn = new Button("Cancel");
      cancelBtn.setOnAction((eventCancel) -> newTagStage.close());

      GridPane newTagPane = new GridPane();
      newTagPane.setHgap(8);
      newTagPane.setVgap(8);
      newTagPane.setPadding(new Insets(10, 10, 10, 10));
      newTagPane.add(textUser, 0, 0, 2, 1);
      newTagPane.add(okBtn, 0, 1);
      newTagPane.add(cancelBtn, 1, 1);
      Scene newTagScene = new Scene(newTagPane);
      newTagStage.setScene(newTagScene);
      newTagStage.show();
    });

    // deleteTagsMenuLabel: when clicked, deletes all selected tags from the global tag list. Note
    // that this function does not affect the tags of individually named pictures; they will still
    // exist in those pictures' names.
    deleteTagsMenuLabel.setOnMouseClicked((event) -> {
      TagManager.deleteTags(listOfAllTags.getSelectionModel().getSelectedItems());
      listOfAllTags.setItems(FXCollections.observableArrayList(TagManager.getArrayListOfTags()));
    });

    // filterTagsItem: when clicked, opens a program window which asks the user to select Tags from
    // the global tag list. It then goes through all tracked pictures to see which, if any, of the
    // pictures are tagged with all the tags the user selected, and returns them. The user also has
    // the option to cancel this operation and return to the main program.
    filterTagsItem.setOnAction((event) -> {
      Stage newFilterStage = new Stage();

      ListView<Tag> filterList = new ListView<>();
      filterList.setItems(FXCollections.observableArrayList(TagManager.getArrayListOfTags()));
      filterList.setEditable(false);
      filterList.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

      ListView<Picture> resultList = new ListView<>();
      ObservableList<Picture> resultArray = FXCollections.observableArrayList();
      resultList.setItems(resultArray);
      resultList.setEditable(false);
      resultList.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
      resultList.setCellFactory(listView -> new ListCell<Picture>() {
        private final ImageView imageView = new ImageView();

        @Override
        public void updateItem(Picture p, boolean empty) {
          super.updateItem(p, empty);
          if (empty) {
            setText(null);
            setGraphic(null);
          } else {
            setText(p.getNameWithTags());
            imageView
                .setImage(new Image("file:" + p.getNameWithTags(), 100, 80, true, true, true));
            setGraphic(imageView);
          }
        }
      });

      Label filters = new Label("Tags to filter by:");
      Label results = new Label("Results:");

      Button searchBtn = new Button("Search");
      searchBtn.setOnAction((eventOK) -> {
        ObservableList<Tag> searchParams = filterList.getSelectionModel().getSelectedItems();
        if (searchParams != null) {
          resultArray.clear();
          resultArray.setAll(PictureManager.findPicsWithTags(searchParams));
        }
      });

      Button selectBtn = new Button("Open in program");
      selectBtn.setOnAction((selectEvent) -> {
        Picture p = resultList.getSelectionModel().getSelectedItem();
        if (p != null) {
          currentID = p.getID();
          currentImage = new Image("file:" + p.getNameWithTags(), 500, 500, true, true);
          iv.setImage(currentImage);
          absolutePath.setText(p.getNameWithTags());
          listOfPictureTags.setItems(FXCollections
              .observableArrayList(p.getArrayTagsUsed()));
          listOfAllTags
              .setItems(FXCollections.observableArrayList(TagManager.getArrayListOfTags()));
          newFilterStage.close();
        }
      });

      Button cancelBtn = new Button("Done");
      cancelBtn.setOnAction((eventCancel) -> newFilterStage.close());

      HBox hbox = new HBox(selectBtn, cancelBtn);
      hbox.setSpacing(10);

      GridPane newFilterPane = new GridPane();
      newFilterPane.setHgap(8);
      newFilterPane.setVgap(8);
      newFilterPane.setPadding(new Insets(10, 10, 10, 10));
      newFilterPane.add(filters, 0, 0);
      newFilterPane.add(results, 1, 0);
      newFilterPane.add(filterList, 0, 1, 1, 3);
      newFilterPane.add(resultList, 1, 1, 1, 3);
      newFilterPane.add(searchBtn, 0, 4);
      newFilterPane.add(hbox, 1, 4);

      Scene newFilterScene = new Scene(newFilterPane);
      newFilterStage.setScene(newFilterScene);
      newFilterStage.show();
    });

    // when the program is exited, this will save the global tag set, as well as all
    // the tags in all tracked pictures. It will also close the master log.
    stage.setOnCloseRequest((WindowEvent event) -> {
      // save everything and close logger
      try {
        TagManager.saveToFile(tagSaveLocation);
      } catch (IOException e) {
        e.printStackTrace();
      }
      try {
        PictureManager.saveToFile(pictureSaveLocation);
      } catch (IOException e) {
        e.printStackTrace();
      }
      LOG.close();
    });

    stage.setScene(scene);
    stage.setTitle("CSC207 FINAL PROJECT");
    stage.show();
  }


}





